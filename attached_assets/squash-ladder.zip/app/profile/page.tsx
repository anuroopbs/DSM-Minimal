import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Clock, MapPin, Trophy, User, Mail, Phone, CalendarIcon } from "lucide-react"

export default function ProfilePage() {
  return (
    <div className="container py-10">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="md:w-1/3">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex flex-col items-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src="/placeholder.svg?height=96&width=96" alt="John Doe" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <CardTitle className="text-2xl">John Doe</CardTitle>
                <CardDescription>Member since January 2025</CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <div className="text-sm text-muted-foreground">Current Rank</div>
                    <div className="font-medium">#12</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <User className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <div className="text-sm text-muted-foreground">Record</div>
                    <div className="font-medium">8 Wins - 4 Losses</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Mail className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <div className="text-sm text-muted-foreground">Email</div>
                    <div className="font-medium">john.doe@example.com</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Phone className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <div className="text-sm text-muted-foreground">Phone</div>
                    <div className="font-medium">+1 (555) 123-4567</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <div className="text-sm text-muted-foreground">Location</div>
                    <div className="font-medium">Downtown Squash Club</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <div className="text-sm text-muted-foreground">Availability</div>
                    <div className="font-medium">Weekdays after 5 PM, Weekends</div>
                  </div>
                </div>
              </div>

              <Button className="w-full mt-6">Edit Profile</Button>
            </CardContent>
          </Card>
        </div>

        <div className="md:w-2/3">
          <Tabs defaultValue="stats" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="stats">Stats</TabsTrigger>
              <TabsTrigger value="history">Match History</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="stats" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex flex-col items-center p-4 border rounded-md">
                      <div className="text-4xl font-bold text-primary">67%</div>
                      <div className="text-sm text-muted-foreground">Win Rate</div>
                    </div>
                    <div className="flex flex-col items-center p-4 border rounded-md">
                      <div className="text-4xl font-bold text-primary">3</div>
                      <div className="text-sm text-muted-foreground">Current Win Streak</div>
                    </div>
                    <div className="flex flex-col items-center p-4 border rounded-md">
                      <div className="text-4xl font-bold text-primary">5</div>
                      <div className="text-sm text-muted-foreground">Highest Rank Achieved</div>
                    </div>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-lg font-medium mb-4">Recent Performance</h3>
                    <div className="flex gap-2">
                      {["W", "W", "L", "W", "L", "W", "W", "W"].map((result, i) => (
                        <div
                          key={i}
                          className={`h-8 w-8 flex items-center justify-center rounded-full text-sm font-medium ${
                            result === "W" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                          }`}
                        >
                          {result}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Rank History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center border rounded-md bg-muted/50">
                    <div className="text-center text-muted-foreground">
                      <p>Rank history chart would appear here</p>
                      <p className="text-sm">(Showing your rank changes over time)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history" className="space-y-4">
              {[1, 2, 3, 4, 5].map((match) => (
                <Card key={match}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <Badge
                          variant={match % 2 === 0 ? "destructive" : "default"}
                          className="h-8 w-8 rounded-full flex items-center justify-center p-0 text-xs"
                        >
                          {match % 2 === 0 ? "L" : "W"}
                        </Badge>
                        <div>
                          <div className="font-medium">vs. {match % 2 === 0 ? "Emma Rodriguez" : "James Wilson"}</div>
                          <div className="text-sm text-muted-foreground flex items-center gap-1">
                            <CalendarIcon className="h-3 w-3" />
                            {match} week{match === 1 ? "" : "s"} ago
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{match % 2 === 0 ? "1-3" : "3-1"}</div>
                        <div className="text-sm text-muted-foreground">
                          Rank change: {match % 2 === 0 ? "-1" : "+1"}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              <div className="flex justify-center mt-4">
                <Button variant="outline">Load More</Button>
              </div>
            </TabsContent>

            <TabsContent value="settings" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Settings</CardTitle>
                  <CardDescription>Update your personal information</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input id="name" defaultValue="John Doe" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" defaultValue="john.doe@example.com" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone</Label>
                        <Input id="phone" defaultValue="+1 (555) 123-4567" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="location">Home Club</Label>
                        <Input id="location" defaultValue="Downtown Squash Club" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="availability">Availability</Label>
                      <Textarea
                        id="availability"
                        placeholder="When are you typically available to play?"
                        defaultValue="Weekdays after 5 PM, Weekends"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        placeholder="Tell others about yourself"
                        defaultValue="Squash enthusiast for 5 years. Looking to improve my game and meet new players."
                      />
                    </div>

                    <Button type="submit">Save Changes</Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Notification Preferences</CardTitle>
                  <CardDescription>Manage how you receive notifications</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Challenge Requests</div>
                        <div className="text-sm text-muted-foreground">When someone challenges you to a match</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <label className="flex items-center gap-2">
                          <input type="checkbox" className="h-4 w-4" defaultChecked />
                          <span className="text-sm">Email</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input type="checkbox" className="h-4 w-4" defaultChecked />
                          <span className="text-sm">Push</span>
                        </label>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Match Reminders</div>
                        <div className="text-sm text-muted-foreground">Reminders about upcoming matches</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <label className="flex items-center gap-2">
                          <input type="checkbox" className="h-4 w-4" defaultChecked />
                          <span className="text-sm">Email</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input type="checkbox" className="h-4 w-4" defaultChecked />
                          <span className="text-sm">Push</span>
                        </label>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Rank Changes</div>
                        <div className="text-sm text-muted-foreground">When your rank changes on the ladder</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <label className="flex items-center gap-2">
                          <input type="checkbox" className="h-4 w-4" defaultChecked />
                          <span className="text-sm">Email</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input type="checkbox" className="h-4 w-4" defaultChecked />
                          <span className="text-sm">Push</span>
                        </label>
                      </div>
                    </div>

                    <Button>Save Preferences</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

