import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import SkillLevelBadge from "@/components/skill-level-badge"
import BackButton from "@/components/back-button"

export default function ProfilePage() {
  return (
    <div className="max-w-4xl mx-auto py-8">
      <BackButton />

      <div className="grid gap-8 md:grid-cols-[1fr_2fr]">
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col items-center gap-4">
              <Avatar className="h-24 w-24">
                <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Profile" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="text-center">
                <h2 className="text-2xl font-bold">Jane Doe</h2>
                <div className="flex justify-center mt-2">
                  <SkillLevelBadge skillLevel="division2" showLabel={true} />
                </div>
                <p className="text-sm text-muted-foreground mt-2">Member since January 2025</p>
              </div>
              <Button className="w-full">Edit Profile</Button>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Player Stats</CardTitle>
              <CardDescription>Your performance in the ladder</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-3xl font-bold text-primary">17-8</p>
                  <p className="text-sm text-muted-foreground">Win-Loss</p>
                </div>
                <div>
                  <p className="text-3xl font-bold text-primary">#4</p>
                  <p className="text-sm text-muted-foreground">Rank</p>
                </div>
                <div>
                  <p className="text-3xl font-bold text-primary">68%</p>
                  <p className="text-sm text-muted-foreground">Win Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="matches">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="matches">Matches</TabsTrigger>
                  <TabsTrigger value="challenges">Challenges</TabsTrigger>
                </TabsList>
                <TabsContent value="matches" className="space-y-4 pt-4">
                  <div className="rounded-lg border p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">vs. Sarah Johnson</p>
                        <p className="text-sm text-muted-foreground">Won 3-1</p>
                      </div>
                      <p className="text-sm text-muted-foreground">2 days ago</p>
                    </div>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">vs. Maria Garcia</p>
                        <p className="text-sm text-muted-foreground">Lost 2-3</p>
                      </div>
                      <p className="text-sm text-muted-foreground">1 week ago</p>
                    </div>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">vs. Lisa Wong</p>
                        <p className="text-sm text-muted-foreground">Won 3-0</p>
                      </div>
                      <p className="text-sm text-muted-foreground">2 weeks ago</p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="challenges" className="space-y-4 pt-4">
                  <div className="rounded-lg border p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Challenge to Emma Rodriguez</p>
                        <p className="text-sm text-muted-foreground">Pending</p>
                      </div>
                      <p className="text-sm text-muted-foreground">1 day ago</p>
                    </div>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Challenge from Jennifer Lee</p>
                        <p className="text-sm text-muted-foreground">Accepted</p>
                      </div>
                      <p className="text-sm text-muted-foreground">3 days ago</p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

