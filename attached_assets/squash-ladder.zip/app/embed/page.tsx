import LadderWidget from "@/components/ladder-widget"
import BackButton from "@/components/back-button"

export default function EmbedPage() {
  return (
    <div className="p-4 max-w-md mx-auto">
      <BackButton />
      <LadderWidget
        title="Squash Ladder Rankings"
        showHeader={true}
        limit={5}
        showChallengeButtons={false}
        showSkillLevel={true}
      />
    </div>
  )
}

