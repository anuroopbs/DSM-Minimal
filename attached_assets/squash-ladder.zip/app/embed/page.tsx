import LadderWidget from "@/components/ladder-widget"

export default function EmbedPage() {
  return (
    <div className="p-4 max-w-md mx-auto">
      <LadderWidget
        title="Squash Ladder Rankings"
        showHeader={true}
        limit={5}
        showChallengeButtons={false}
        showSkillLevel={true}
      />
    </div>
  )
}

