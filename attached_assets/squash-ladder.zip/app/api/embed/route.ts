import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const widgetType = searchParams.get("type") || "ladder"
  const gender = searchParams.get("gender") || "all"
  const limit = Number.parseInt(searchParams.get("limit") || "5", 10)

  // Sample data - in a real implementation, this would come from your database
  const malePlayers = [
    {
      id: "1",
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "male",
      record: { wins: 24, losses: 3 },
      movement: "none",
      lastMatch: "2 days ago",
    },
    {
      id: "2",
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "male",
      record: { wins: 22, losses: 5 },
      movement: "up",
      lastMatch: "Yesterday",
    },
    {
      id: "3",
      name: "James Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "male",
      record: { wins: 19, losses: 7 },
      movement: "down",
      lastMatch: "3 days ago",
    },
    {
      id: "4",
      name: "Robert Taylor",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "male",
      record: { wins: 18, losses: 8 },
      movement: "up",
      lastMatch: "1 week ago",
    },
    {
      id: "5",
      name: "John Smith",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "male",
      record: { wins: 16, losses: 9 },
      movement: "none",
      lastMatch: "5 days ago",
    },
  ]

  const femalePlayers = [
    {
      id: "6",
      name: "Emma Rodriguez",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "female",
      record: { wins: 21, losses: 4 },
      movement: "up",
      lastMatch: "Yesterday",
    },
    {
      id: "7",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "female",
      record: { wins: 19, losses: 6 },
      movement: "none",
      lastMatch: "3 days ago",
    },
    {
      id: "8",
      name: "Maria Garcia",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "female",
      record: { wins: 17, losses: 7 },
      movement: "up",
      lastMatch: "4 days ago",
    },
    {
      id: "9",
      name: "Jennifer Lee",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "female",
      record: { wins: 15, losses: 8 },
      movement: "down",
      lastMatch: "1 week ago",
    },
    {
      id: "10",
      name: "Lisa Wong",
      avatar: "/placeholder.svg?height=40&width=40",
      gender: "female",
      record: { wins: 14, losses: 9 },
      movement: "none",
      lastMatch: "2 weeks ago",
    },
  ]

  let responseData = []

  if (gender === "male") {
    responseData = malePlayers.slice(0, limit)
  } else if (gender === "female") {
    responseData = femalePlayers.slice(0, limit)
  } else {
    // For 'all', return both but respect the limit
    const halfLimit = Math.ceil(limit / 2)
    responseData = [...malePlayers.slice(0, halfLimit), ...femalePlayers.slice(0, halfLimit)]
  }

  return NextResponse.json({
    data: responseData,
    meta: {
      total:
        gender === "male"
          ? malePlayers.length
          : gender === "female"
            ? femalePlayers.length
            : malePlayers.length + femalePlayers.length,
    },
  })
}

