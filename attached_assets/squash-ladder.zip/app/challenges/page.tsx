import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { CalendarIcon, Clock } from "lucide-react"

export default function ChallengesPage() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Challenges</h1>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Challenge from Alex Thompson</CardTitle>
                  <CardDescription>Received 2 days ago</CardDescription>
                </div>
                <Badge>Pending Response</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Alex Thompson" />
                  <AvatarFallback>AT</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">Alex Thompson</div>
                  <div className="text-sm text-muted-foreground">Rank #8 • Record: 15-7</div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                  <span>Proposed dates:</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <Button variant="outline" className="justify-start">
                    <div className="flex flex-col items-start">
                      <span>May 15, 2025</span>
                      <span className="text-xs text-muted-foreground">6:00 PM</span>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <div className="flex flex-col items-start">
                      <span>May 16, 2025</span>
                      <span className="text-xs text-muted-foreground">7:30 PM</span>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <div className="flex flex-col items-start">
                      <span>May 18, 2025</span>
                      <span className="text-xs text-muted-foreground">5:00 PM</span>
                    </div>
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Suggest Alternative</Button>
              <Button>Accept Challenge</Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Your Challenge to Maria Garcia</CardTitle>
                  <CardDescription>Sent yesterday</CardDescription>
                </div>
                <Badge variant="outline">Awaiting Response</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Maria Garcia" />
                  <AvatarFallback>MG</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">Maria Garcia</div>
                  <div className="text-sm text-muted-foreground">Rank #9 • Record: 14-8</div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                  <span>Your proposed dates:</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <div className="border rounded-md p-2 text-sm">
                    <div>May 20, 2025</div>
                    <div className="text-xs text-muted-foreground">6:30 PM</div>
                  </div>
                  <div className="border rounded-md p-2 text-sm">
                    <div>May 21, 2025</div>
                    <div className="text-xs text-muted-foreground">7:00 PM</div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Cancel Challenge
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="upcoming" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Match vs. Sarah Johnson</CardTitle>
                  <CardDescription>Scheduled for tomorrow</CardDescription>
                </div>
                <Badge className="bg-green-500">Confirmed</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Sarah Johnson" />
                  <AvatarFallback>SJ</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">Sarah Johnson</div>
                  <div className="text-sm text-muted-foreground">Rank #4 • Record: 18-8</div>
                </div>
              </div>

              <div className="flex items-center gap-3 text-sm border rounded-md p-3">
                <Clock className="h-5 w-5 text-muted-foreground" />
                <div>
                  <div className="font-medium">March 30, 2025 at 6:00 PM</div>
                  <div className="text-muted-foreground">Downtown Squash Club - Court 3</div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Reschedule</Button>
              <Button variant="destructive">Cancel Match</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Match vs. James Wilson</CardTitle>
                  <CardDescription>Played 5 days ago</CardDescription>
                </div>
                <Badge variant="secondary">Completed</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src="/placeholder.svg?height=48&width=48" alt="James Wilson" />
                  <AvatarFallback>JW</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">James Wilson</div>
                  <div className="text-sm text-muted-foreground">Rank #5 • Record: 16-9</div>
                </div>
              </div>

              <div className="border rounded-md p-4">
                <div className="text-center mb-2 font-medium">Match Result</div>
                <div className="flex justify-center items-center gap-3 text-xl">
                  <span className="font-bold text-green-500">3</span>
                  <span className="text-sm text-muted-foreground">-</span>
                  <span className="font-bold text-muted-foreground">1</span>
                </div>
                <div className="text-center text-sm text-muted-foreground mt-2">You won</div>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="#" className="text-sm text-primary hover:underline w-full text-center">
                View Match Details
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Match vs. Emma Rodriguez</CardTitle>
                  <CardDescription>Played 2 weeks ago</CardDescription>
                </div>
                <Badge variant="secondary">Completed</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Emma Rodriguez" />
                  <AvatarFallback>ER</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">Emma Rodriguez</div>
                  <div className="text-sm text-muted-foreground">Rank #2 • Record: 22-5</div>
                </div>
              </div>

              <div className="border rounded-md p-4">
                <div className="text-center mb-2 font-medium">Match Result</div>
                <div className="flex justify-center items-center gap-3 text-xl">
                  <span className="font-bold text-muted-foreground">1</span>
                  <span className="text-sm text-muted-foreground">-</span>
                  <span className="font-bold text-green-500">3</span>
                </div>
                <div className="text-center text-sm text-muted-foreground mt-2">You lost</div>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="#" className="text-sm text-primary hover:underline w-full text-center">
                View Match Details
              </Link>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

