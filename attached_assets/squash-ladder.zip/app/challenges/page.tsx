import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import SkillLevelBadge from "@/components/skill-level-badge"
import BackButton from "@/components/back-button"

export default function ChallengesPage() {
  return (
    <div className="max-w-4xl mx-auto py-8">
      <BackButton />

      <h1 className="text-3xl font-bold mb-6">Challenges</h1>

      <Tabs defaultValue="incoming">
        <TabsList className="grid w-full grid-cols-3 mb-8 max-w-md">
          <TabsTrigger value="incoming">Incoming</TabsTrigger>
          <TabsTrigger value="outgoing">Outgoing</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="incoming" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Incoming Challenges</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Jennifer Lee" />
                      <AvatarFallback>JL</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">Jennifer Lee</p>
                        <SkillLevelBadge skillLevel="division4" small />
                      </div>
                      <p className="text-sm text-muted-foreground">Rank #9 • Challenged 3 days ago</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      Decline
                    </Button>
                    <Button size="sm">Accept</Button>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Lisa Wong" />
                      <AvatarFallback>LW</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">Lisa Wong</p>
                        <SkillLevelBadge skillLevel="division5" small />
                      </div>
                      <p className="text-sm text-muted-foreground">Rank #10 • Challenged 1 week ago</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      Decline
                    </Button>
                    <Button size="sm">Accept</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="outgoing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Outgoing Challenges</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Emma Rodriguez" />
                      <AvatarFallback>ER</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">Emma Rodriguez</p>
                        <SkillLevelBadge skillLevel="premier" small />
                      </div>
                      <p className="text-sm text-muted-foreground">Rank #1 • Challenged 1 day ago</p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline">
                    Cancel
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Sarah Johnson" />
                      <AvatarFallback>SJ</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">Sarah Johnson</p>
                        <SkillLevelBadge skillLevel="division1" small />
                      </div>
                      <p className="text-sm text-muted-foreground">Rank #2 • Challenged 2 days ago</p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline">
                    Cancel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Challenge History</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Maria Garcia" />
                      <AvatarFallback>MG</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">Maria Garcia</p>
                        <SkillLevelBadge skillLevel="division2" small />
                      </div>
                      <p className="text-sm text-muted-foreground">
                        <span className="text-green-500 font-medium">Accepted</span> • 2 weeks ago
                      </p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline">
                    View Match
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Jennifer Lee" />
                      <AvatarFallback>JL</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">Jennifer Lee</p>
                        <SkillLevelBadge skillLevel="division4" small />
                      </div>
                      <p className="text-sm text-muted-foreground">
                        <span className="text-red-500 font-medium">Declined</span> • 3 weeks ago
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

