import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, MessageSquare, Users } from "lucide-react"

export default function CommunityPage() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Community</h1>

      <Tabs defaultValue="players" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="players">Players</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
          <TabsTrigger value="discussions">Discussions</TabsTrigger>
        </TabsList>

        <TabsContent value="players" className="space-y-6">
          <div className="flex justify-between items-center">
            <div className="text-lg font-medium">Find Players</div>
            <div className="relative w-64">
              <Input placeholder="Search by name or club..." />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((player) => (
              <Card key={player}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={`/placeholder.svg?height=48&width=48`} alt={`Player ${player}`} />
                      <AvatarFallback>{`P${player}`}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="font-medium">
                        {
                          [
                            "Michael Chen",
                            "Emma Rodriguez",
                            "David Kim",
                            "Sarah Johnson",
                            "James Wilson",
                            "Maria Garcia",
                          ][player - 1]
                        }
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">
                        Rank #{[1, 2, 3, 4, 5, 9][player - 1]} •{" "}
                        {
                          [
                            "Downtown Squash Club",
                            "City Sports Center",
                            "University Club",
                            "Downtown Squash Club",
                            "City Sports Center",
                            "University Club",
                          ][player - 1]
                        }
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {
                          [
                            "Available weekday evenings",
                            "Available weekends",
                            "Available mornings",
                            "Available weekday evenings",
                            "Available weekends",
                            "Available mornings",
                          ][player - 1]
                        }
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="px-6 py-4 border-t bg-muted/50">
                  <div className="flex gap-2 w-full">
                    <Button variant="outline" size="sm" className="flex-1">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Message
                    </Button>
                    <Button size="sm" className="flex-1">
                      Challenge
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>

          <div className="flex justify-center">
            <Button variant="outline">Load More</Button>
          </div>
        </TabsContent>

        <TabsContent value="events" className="space-y-6">
          <div className="flex justify-between items-center">
            <div className="text-lg font-medium">Upcoming Events</div>
            <Button>
              <CalendarIcon className="h-4 w-4 mr-2" />
              Create Event
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((event) => (
              <Card key={event}>
                <CardHeader>
                  <CardTitle>
                    {["Spring Tournament", "Beginner Workshop", "Club Championship", "Friendly Round Robin"][event - 1]}
                  </CardTitle>
                  <CardDescription>
                    {["April 15-17, 2025", "May 5, 2025", "June 10-12, 2025", "April 30, 2025"][event - 1]}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {
                      [
                        "Join our annual spring tournament with divisions for all skill levels. Prizes for winners and runners-up.",
                        "A workshop for beginners to learn the basics of squash. Equipment provided.",
                        "The annual club championship to crown the best players in the club. Multiple divisions available.",
                        "A casual round robin event for players to meet and play with new opponents.",
                      ][event - 1]
                    }
                  </p>
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span>{[24, 12, 32, 16][event - 1]} participants</span>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="text-sm font-medium">
                    {["$25 entry fee", "Free", "$30 entry fee", "$10 entry fee"][event - 1]}
                  </div>
                  <Button variant={event === 2 ? "outline" : "default"}>{event === 2 ? "Full" : "Register"}</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="discussions" className="space-y-6">
          <div className="flex justify-between items-center">
            <div className="text-lg font-medium">Forum Discussions</div>
            <Button>
              <MessageSquare className="h-4 w-4 mr-2" />
              New Topic
            </Button>
          </div>

          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((topic) => (
              <Card key={topic}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={`User ${topic}`} />
                        <AvatarFallback>{`U${topic}`}</AvatarFallback>
                      </Avatar>
                      <div>
                        <Link href="#" className="font-medium hover:underline">
                          {
                            [
                              "Recommended rackets for beginners?",
                              "Tips for improving your backhand",
                              "Rule clarification: let vs stroke",
                              "Looking for regular playing partners",
                              "Tournament strategy discussion",
                            ][topic - 1]
                          }
                        </Link>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                          <span>
                            Started by{" "}
                            {
                              ["Michael Chen", "Emma Rodriguez", "David Kim", "Sarah Johnson", "James Wilson"][
                                topic - 1
                              ]
                            }
                          </span>
                          <span>•</span>
                          <span>{[12, 8, 15, 4, 7][topic - 1]} replies</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {["2 hours ago", "Yesterday", "3 days ago", "1 week ago", "2 weeks ago"][topic - 1]}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="flex justify-center">
            <Button variant="outline">Load More Topics</Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

