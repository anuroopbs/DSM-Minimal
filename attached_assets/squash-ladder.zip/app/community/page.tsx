import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"
import SkillLevelBadge from "@/components/skill-level-badge"
import BackButton from "@/components/back-button"

export default function CommunityPage() {
  return (
    <div className="max-w-4xl mx-auto py-8">
      <BackButton />

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Community</h1>
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Search players..." className="w-[250px] pl-8" />
        </div>
      </div>

      <Tabs defaultValue="players">
        <TabsList className="grid w-full grid-cols-3 mb-8 max-w-md">
          <TabsTrigger value="players">Players</TabsTrigger>
          <TabsTrigger value="clubs">Clubs</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
        </TabsList>

        <TabsContent value="players" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            {[
              {
                name: "Emma Rodriguez",
                avatar: "/placeholder.svg?height=40&width=40",
                skillLevel: "premier",
                rank: 1,
                club: "Downtown Squash Club",
              },
              {
                name: "Sarah Johnson",
                avatar: "/placeholder.svg?height=40&width=40",
                skillLevel: "division1",
                rank: 2,
                club: "University Squash Center",
              },
              {
                name: "Maria Garcia",
                avatar: "/placeholder.svg?height=40&width=40",
                skillLevel: "division2",
                rank: 3,
                club: "Eastside Racquet Club",
              },
              {
                name: "Jennifer Lee",
                avatar: "/placeholder.svg?height=40&width=40",
                skillLevel: "division4",
                rank: 9,
                club: "Downtown Squash Club",
              },
            ].map((player, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarImage src={player.avatar} alt={player.name} />
                      <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{player.name}</p>
                        <SkillLevelBadge skillLevel={player.skillLevel as any} small />
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>Rank #{player.rank}</span>
                        <span>•</span>
                        <span>{player.club}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end mt-4">
                    <Button size="sm">View Profile</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="flex justify-center">
            <Button variant="outline">Load More</Button>
          </div>
        </TabsContent>

        <TabsContent value="clubs" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            {[
              {
                name: "Downtown Squash Club",
                image: "/placeholder.svg?height=80&width=160",
                members: 42,
                location: "123 Main St, Downtown",
              },
              {
                name: "University Squash Center",
                image: "/placeholder.svg?height=80&width=160",
                members: 38,
                location: "University Campus, Building 5",
              },
              {
                name: "Eastside Racquet Club",
                image: "/placeholder.svg?height=80&width=160",
                members: 29,
                location: "456 East Ave, Eastside",
              },
              {
                name: "Westside Fitness & Squash",
                image: "/placeholder.svg?height=80&width=160",
                members: 35,
                location: "789 West Blvd, Westside",
              },
            ].map((club, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="aspect-[2/1] overflow-hidden rounded-md mb-4">
                    <img
                      src={club.image || "/placeholder.svg"}
                      alt={club.name}
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <h3 className="font-bold text-lg">{club.name}</h3>
                  <div className="text-sm text-muted-foreground mt-1">
                    <p>{club.members} members</p>
                    <p>{club.location}</p>
                  </div>
                  <div className="flex justify-end mt-4">
                    <Button size="sm">View Club</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="events" className="space-y-6">
          <div className="grid gap-4">
            {[
              {
                name: "Summer Championship",
                date: "June 10-12, 2025",
                location: "Downtown Squash Club",
                description: "Annual summer championship with divisions for all skill levels.",
              },
              {
                name: "Beginner's Tournament",
                date: "July 5, 2025",
                location: "University Squash Center",
                description: "Special tournament for Division 5 and 6 players to gain competitive experience.",
              },
              {
                name: "Pro Exhibition Match",
                date: "July 15, 2025",
                location: "Eastside Racquet Club",
                description: "Watch professional players compete in an exhibition match with Q&A session.",
              },
            ].map((event, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-lg">{event.name}</h3>
                      <div className="text-sm text-muted-foreground mt-1">
                        <p>{event.date}</p>
                        <p>{event.location}</p>
                      </div>
                      <p className="mt-2">{event.description}</p>
                    </div>
                    <Button>Register</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

