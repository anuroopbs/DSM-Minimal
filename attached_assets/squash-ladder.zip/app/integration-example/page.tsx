import LadderEmbed from "@/components/ladder-embed"

export default function IntegrationExample() {
  return (
    <div className="max-w-6xl mx-auto p-8">
      <h1 className="text-3xl font-bold mb-8">Your Club Website</h1>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="prose max-w-none">
            <h2>Welcome to Our Squash Club</h2>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget aliquam ultricies, nunc
              nisl aliquet nunc, quis aliquam nisl nunc quis nisl. Nullam euismod, nisl eget aliquam ultricies, nunc
              nisl aliquet nunc, quis aliquam nisl nunc quis nisl.
            </p>

            <h3>Upcoming Events</h3>
            <ul>
              <li>Club Championship - June 10-12, 2025</li>
              <li>Beginner's Tournament - July 5, 2025</li>
              <li>Pro Exhibition Match - July 15, 2025</li>
            </ul>

            <h3>Club News</h3>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget aliquam ultricies, nunc
              nisl aliquet nunc, quis aliquam nisl nunc quis nisl.
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="border rounded-lg p-4">
            <h3 className="font-bold mb-2">Club Hours</h3>
            <p className="text-sm">
              Monday - Friday: 6am - 10pm
              <br />
              Saturday - Sunday: 8am - 8pm
            </p>
          </div>

          <div className="border rounded-lg p-4">
            <h3 className="font-bold mb-2">Contact Us</h3>
            <p className="text-sm">
              123 Main Street
              <br />
              Anytown, USA 12345
              <br />
              (555) 123-4567
              <br />
              info@squashclub.com
            </p>
          </div>

          {/* This is where the ladder widget is embedded */}
          <LadderEmbed baseUrl="/ladder" />
        </div>
      </div>
    </div>
  )
}

