import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function MatchReportPage() {
  return (
    <div className="container py-10 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Report Match Result</h1>

      <Card>
        <CardHeader>
          <CardTitle>Match vs. Sarah Johnson</CardTitle>
          <CardDescription>March 30, 2025 at Downtown Squash Club</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-center gap-4">
            <div className="text-center">
              <Avatar className="h-16 w-16 mx-auto mb-2">
                <AvatarImage src="/placeholder.svg?height=64&width=64" alt="You" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="font-medium">You</div>
              <div className="text-sm text-muted-foreground">Rank #12</div>
            </div>

            <div className="text-2xl font-bold text-muted-foreground">vs</div>

            <div className="text-center">
              <Avatar className="h-16 w-16 mx-auto mb-2">
                <AvatarImage src="/placeholder.svg?height=64&width=64" alt="Sarah Johnson" />
                <AvatarFallback>SJ</AvatarFallback>
              </Avatar>
              <div className="font-medium">Sarah Johnson</div>
              <div className="text-sm text-muted-foreground">Rank #4</div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-3">Match Format</h3>
            <RadioGroup defaultValue="best-of-5">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="best-of-3" id="best-of-3" />
                <Label htmlFor="best-of-3">Best of 3 Games</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="best-of-5" id="best-of-5" />
                <Label htmlFor="best-of-5">Best of 5 Games</Label>
              </div>
            </RadioGroup>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-3">Match Result</h3>
            <RadioGroup defaultValue="you-won">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="you-won" id="you-won" />
                <Label htmlFor="you-won">You Won</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="opponent-won" id="opponent-won" />
                <Label htmlFor="opponent-won">Sarah Johnson Won</Label>
              </div>
            </RadioGroup>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-3">Game Scores</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="your-score-1">Your Score - Game 1</Label>
                <Input type="number" id="your-score-1" min="0" max="21" defaultValue="11" />
              </div>
              <div>
                <Label htmlFor="opponent-score-1">Sarah's Score - Game 1</Label>
                <Input type="number" id="opponent-score-1" min="0" max="21" defaultValue="7" />
              </div>

              <div>
                <Label htmlFor="your-score-2">Your Score - Game 2</Label>
                <Input type="number" id="your-score-2" min="0" max="21" defaultValue="11" />
              </div>
              <div>
                <Label htmlFor="opponent-score-2">Sarah's Score - Game 2</Label>
                <Input type="number" id="opponent-score-2" min="0" max="21" defaultValue="9" />
              </div>

              <div>
                <Label htmlFor="your-score-3">Your Score - Game 3</Label>
                <Input type="number" id="your-score-3" min="0" max="21" defaultValue="8" />
              </div>
              <div>
                <Label htmlFor="opponent-score-3">Sarah's Score - Game 3</Label>
                <Input type="number" id="opponent-score-3" min="0" max="21" defaultValue="11" />
              </div>

              <div>
                <Label htmlFor="your-score-4">Your Score - Game 4</Label>
                <Input type="number" id="your-score-4" min="0" max="21" defaultValue="11" />
              </div>
              <div>
                <Label htmlFor="opponent-score-4">Sarah's Score - Game 4</Label>
                <Input type="number" id="opponent-score-4" min="0" max="21" defaultValue="5" />
              </div>
            </div>
          </div>

          <div>
            <Label htmlFor="comments">Comments (Optional)</Label>
            <Textarea id="comments" placeholder="Add any comments about the match..." className="resize-none" />
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline">Save as Draft</Button>
          <Button>Submit Result</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

