"use client"

import { useState } from "react"
import PlayerRegistrationForm, { type PlayerFormData } from "@/components/player-registration-form"
import { Trophy } from "lucide-react"

export default function RegisterPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleSubmit = async (data: PlayerFormData) => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      console.log("Registration data:", data)
      setIsLoading(false)
      setIsSuccess(true)
    }, 1500)
  }

  if (isSuccess) {
    return (
      <div className="container max-w-md mx-auto py-12">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <Trophy className="h-12 w-12 text-primary" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Registration Successful!</h1>
          <p className="text-muted-foreground mb-6">
            Thank you for joining the squash ladder. Your information has been submitted.
          </p>
          <p className="text-sm">
            You will be notified when your account is approved and your initial ladder position is assigned.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="container max-w-md mx-auto py-12">
      <PlayerRegistrationForm onSubmit={handleSubmit} isLoading={isLoading} />
    </div>
  )
}

