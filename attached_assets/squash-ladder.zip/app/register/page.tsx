"use client"

import PlayerRegistrationForm from "@/components/player-registration-form"
import BackButton from "@/components/back-button"

export default function RegisterPage() {
  return (
    <div className="max-w-2xl mx-auto py-8">
      <BackButton />
      <PlayerRegistrationForm
        onSubmit={(data) => {
          // In a real app, this would submit to an API
          console.log("Form submitted:", data)
        }}
      />
    </div>
  )
}

