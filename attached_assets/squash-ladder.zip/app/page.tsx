import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Trophy, ChevronUp, ChevronDown, Minus, Filter } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"

// Define skill level type
type SkillLevel =
  | "premier" // Professional-level players
  | "division1" // Advanced 2
  | "division2" // Advanced 1
  | "division3" // Intermediate 2
  | "division4" // Intermediate 1
  | "division5" // Beginner 2
  | "division6" // Beginner 1

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">SquashLadder</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-primary">
              Ladder
            </Link>
            <Link href="/challenges" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Challenges
            </Link>
            <Link href="/profile" className="text-sm font-medium text-muted-foreground hover:text-primary">
              My Profile
            </Link>
            <Link href="/community" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Community
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button size="sm">Register</Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="container py-8">
          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center gap-2">
                  <h2 className="text-2xl font-bold">Total Players</h2>
                  <div className="text-5xl font-bold text-primary">36</div>
                  <p className="text-sm text-muted-foreground">Active in the ladder</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center gap-2">
                  <h2 className="text-2xl font-bold">Recent Matches</h2>
                  <div className="text-3xl font-bold">
                    <span className="text-primary">12</span>
                  </div>
                  <p className="text-sm text-muted-foreground">In the last 7 days</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center gap-2">
                  <h2 className="text-2xl font-bold">Next Event</h2>
                  <div className="text-xl font-medium">Club Championship</div>
                  <p className="text-sm text-muted-foreground">June 10-12, 2025</p>
                  <Button size="sm" className="mt-2">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
        <section className="container py-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold">Ladder Rankings</h2>
            <div className="flex items-center gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter by Skill
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-0" align="end">
                  <Command>
                    <CommandInput placeholder="Search division..." />
                    <CommandList>
                      <CommandEmpty>No division found.</CommandEmpty>
                      <CommandGroup>
                        <CommandItem className="flex flex-col items-start py-3">
                          <div className="flex items-center gap-2">
                            <Badge variant="destructive">Premier</Badge>
                            <span className="font-medium">Professional</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            Professional-level players with elite skill, fitness, and tactical mastery
                          </p>
                        </CommandItem>
                        <CommandItem className="flex flex-col items-start py-3">
                          <div className="flex items-center gap-2">
                            <Badge variant="destructive">Division 1</Badge>
                            <span className="font-medium">Advanced 2</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            Top national players with strong tournament results and advanced gameplay
                          </p>
                        </CommandItem>
                        <CommandItem className="flex flex-col items-start py-3">
                          <div className="flex items-center gap-2">
                            <Badge variant="default">Division 2</Badge>
                            <span className="font-medium">Advanced 1</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            High-level club and top regional players with consistent wins and control
                          </p>
                        </CommandItem>
                        <CommandItem className="flex flex-col items-start py-3">
                          <div className="flex items-center gap-2">
                            <Badge variant="default">Division 3</Badge>
                            <span className="font-medium">Intermediate 2</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            Competitive intermediates with solid match performance and improving strategy
                          </p>
                        </CommandItem>
                        <CommandItem className="flex flex-col items-start py-3">
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary">Division 4</Badge>
                            <span className="font-medium">Intermediate 1</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            Players developing match tactics, movement, and shot variety
                          </p>
                        </CommandItem>
                        <CommandItem className="flex flex-col items-start py-3">
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary">Division 5</Badge>
                            <span className="font-medium">Beginner 2</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            Newer players (4–12 months) building technique, consistency, and confidence in games
                          </p>
                        </CommandItem>
                        <CommandItem className="flex flex-col items-start py-3">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Division 6</Badge>
                            <span className="font-medium">Beginner 1</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            Brand new to squash (0–3 months); learning rules, strokes, and basic movement
                          </p>
                        </CommandItem>
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Search players..."
                  className="h-9 rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                />
              </div>
            </div>
          </div>

          <Tabs defaultValue="male" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8 max-w-md mx-auto">
              <TabsTrigger value="male">Men's Ladder</TabsTrigger>
              <TabsTrigger value="female">Women's Ladder</TabsTrigger>
            </TabsList>

            <TabsContent value="male" className="space-y-4">
              {malePlayers.map((player, index) => (
                <LadderPlayerCard key={player.id} player={player} rank={index + 1} isTopThree={index < 3} />
              ))}
            </TabsContent>

            <TabsContent value="female" className="space-y-4">
              {femalePlayers.map((player, index) => (
                <LadderPlayerCard key={player.id} player={player} rank={index + 1} isTopThree={index < 3} />
              ))}
            </TabsContent>
          </Tabs>
        </section>
      </main>
      <footer className="border-t py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} SquashLadder. All rights reserved.
          </p>
          <nav className="flex gap-4">
            <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
              Terms
            </Link>
            <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
              Privacy
            </Link>
            <Link href="#" className="text-sm text-muted-foreground hover:text-primary">
              Contact
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

interface Player {
  id: string
  name: string
  avatar: string
  gender: "male" | "female"
  skillLevel: SkillLevel
  record: {
    wins: number
    losses: number
  }
  movement: "up" | "down" | "none"
  lastMatch: string
}

interface LadderPlayerCardProps {
  player: Player
  rank: number
  isTopThree: boolean
}

function LadderPlayerCard({ player, rank, isTopThree }: LadderPlayerCardProps) {
  return (
    <div className="flex items-center justify-between rounded-lg border p-4 transition-colors hover:bg-accent/50">
      <div className="flex items-center gap-4">
        <div className="relative flex h-10 w-10 items-center justify-center rounded-full bg-muted font-bold">
          {rank}
          {isTopThree && (
            <div className="absolute -top-1 -right-1">
              <Trophy className="h-4 w-4 text-yellow-500" />
            </div>
          )}
        </div>
        <Avatar className="h-10 w-10">
          <AvatarImage src={player.avatar} alt={player.name} />
          <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-medium">{player.name}</span>
            <SkillLevelBadge skillLevel={player.skillLevel} />
          </div>
          <div className="text-sm text-muted-foreground">
            {player.record.wins}-{player.record.losses}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center">
          {player.movement === "up" && <ChevronUp className="h-4 w-4 text-green-500" />}
          {player.movement === "down" && <ChevronDown className="h-4 w-4 text-red-500" />}
          {player.movement === "none" && <Minus className="h-4 w-4 text-muted-foreground" />}
          <span className="text-sm text-muted-foreground ml-1">{player.lastMatch}</span>
        </div>
        <Button size="sm">Challenge</Button>
      </div>
    </div>
  )
}

function SkillLevelBadge({ skillLevel }: { skillLevel: SkillLevel }) {
  let badgeVariant: "outline" | "secondary" | "default" | "destructive"
  let displayText: string

  switch (skillLevel) {
    case "premier":
      badgeVariant = "destructive"
      displayText = "Premier"
      break
    case "division1":
      badgeVariant = "destructive"
      displayText = "Division 1"
      break
    case "division2":
      badgeVariant = "default"
      displayText = "Division 2"
      break
    case "division3":
      badgeVariant = "default"
      displayText = "Division 3"
      break
    case "division4":
      badgeVariant = "secondary"
      displayText = "Division 4"
      break
    case "division5":
      badgeVariant = "secondary"
      displayText = "Division 5"
      break
    case "division6":
      badgeVariant = "outline"
      displayText = "Division 6"
      break
  }

  return (
    <Badge variant={badgeVariant} className="text-xs">
      {displayText}
    </Badge>
  )
}

// Male players data with skill levels
const malePlayers: Player[] = [
  {
    id: "1",
    name: "Michael Chen",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "premier",
    record: { wins: 24, losses: 3 },
    movement: "none",
    lastMatch: "2 days ago",
  },
  {
    id: "2",
    name: "David Kim",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "division1",
    record: { wins: 22, losses: 5 },
    movement: "up",
    lastMatch: "Yesterday",
  },
  {
    id: "3",
    name: "James Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "division2",
    record: { wins: 19, losses: 7 },
    movement: "down",
    lastMatch: "3 days ago",
  },
  {
    id: "4",
    name: "Robert Taylor",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "division3",
    record: { wins: 18, losses: 8 },
    movement: "up",
    lastMatch: "1 week ago",
  },
  {
    id: "5",
    name: "John Smith",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "division4",
    record: { wins: 16, losses: 9 },
    movement: "none",
    lastMatch: "5 days ago",
  },
]

// Female players data with skill levels
const femalePlayers: Player[] = [
  {
    id: "6",
    name: "Emma Rodriguez",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "premier",
    record: { wins: 21, losses: 4 },
    movement: "up",
    lastMatch: "Yesterday",
  },
  {
    id: "7",
    name: "Sarah Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "division1",
    record: { wins: 19, losses: 6 },
    movement: "none",
    lastMatch: "3 days ago",
  },
  {
    id: "8",
    name: "Maria Garcia",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "division2",
    record: { wins: 17, losses: 7 },
    movement: "up",
    lastMatch: "4 days ago",
  },
  {
    id: "9",
    name: "Jennifer Lee",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "division4",
    record: { wins: 15, losses: 8 },
    movement: "down",
    lastMatch: "1 week ago",
  },
  {
    id: "10",
    name: "Lisa Wong",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "division5",
    record: { wins: 14, losses: 9 },
    movement: "none",
    lastMatch: "2 weeks ago",
  },
]

