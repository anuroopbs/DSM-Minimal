export default function EmbedScriptPage() {
  const embedCode = `
<!-- Add this to your website where you want the ladder to appear -->
<div id="squash-ladder-container"></div>

<!-- Add this script to the bottom of your page, just before the closing </body> tag -->
<script>
  (function() {
    // Create an iframe to load the ladder
    var iframe = document.createElement('iframe');
    iframe.src = 'https://your-domain.com/ladder/embed';
    iframe.style.width = '100%';
    iframe.style.height = '500px';
    iframe.style.border = 'none';
    iframe.style.overflow = 'hidden';
    
    // Add the iframe to the container
    var container = document.getElementById('squash-ladder-container');
    if (container) {
      container.appendChild(iframe);
    }
    
    // Adjust iframe height based on content
    window.addEventListener('message', function(event) {
      if (event.data && event.data.type === 'resize-ladder') {
        iframe.style.height = event.data.height + 'px';
      }
    });
  })();
</script>
`

  return (
    <div className="max-w-3xl mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">Embed the Squash Ladder on Your Website</h1>

      <div className="space-y-6">
        <p>Copy and paste the following code into your website to embed the squash ladder:</p>

        <div className="bg-muted p-4 rounded-md overflow-x-auto">
          <pre className="text-sm">{embedCode}</pre>
        </div>

        <div className="bg-yellow-100 dark:bg-yellow-900 p-4 rounded-md">
          <h3 className="font-bold text-yellow-800 dark:text-yellow-200">Important Notes</h3>
          <ul className="list-disc pl-5 mt-2 text-yellow-800 dark:text-yellow-200 text-sm space-y-1">
            <li>Replace 'https://your-domain.com/ladder/embed' with the actual URL of your ladder embed page.</li>
            <li>You may need to adjust the height value (500px) based on your specific layout.</li>
            <li>This script creates an iframe that loads the ladder content from your Next.js application.</li>
          </ul>
        </div>

        <h2 className="text-xl font-bold mt-8">Alternative: Direct Link</h2>
        <p>If you prefer, you can simply add a link to the ladder page:</p>

        <div className="bg-muted p-4 rounded-md overflow-x-auto">
          <pre className="text-sm">{`<a href="https://your-domain.com/ladder">View Squash Ladder</a>`}</pre>
        </div>
      </div>
    </div>
  )
}

