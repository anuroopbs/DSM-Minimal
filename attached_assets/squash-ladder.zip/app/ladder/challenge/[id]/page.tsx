import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import SkillLevelBadge from "@/components/skill-level-badge"
import { ArrowLeft } from "lucide-react"

interface ChallengePageProps {
  params: {
    id: string
  }
}

export default function ChallengePage({ params }: ChallengePageProps) {
  // In a real app, you would fetch the player data based on the ID
  const playerId = params.id

  // Mock player data
  const player = {
    id: playerId,
    name: playerId.startsWith("1") ? "John Smith" : "Emma Rodriguez",
    avatar: "/placeholder.svg?height=80&width=80",
    skillLevel: playerId.startsWith("1") ? "division4" : "premier",
    rank: playerId.startsWith("1") ? 5 : 1,
    record: { wins: playerId.startsWith("1") ? 16 : 21, losses: playerId.startsWith("1") ? 9 : 4 },
  }

  return (
    <div className="max-w-md mx-auto py-8">
      <div className="mb-4">
        <Button variant="ghost" size="sm" asChild className="gap-1 px-2 hover:bg-accent">
          <Link href="/ladder">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Ladder</span>
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Challenge Player</CardTitle>
          <CardDescription>Send a challenge to this player</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={player.avatar} alt={player.name} />
              <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-xl font-bold">{player.name}</h3>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-sm text-muted-foreground">Rank #{player.rank}</span>
                <span className="text-sm text-muted-foreground">•</span>
                <SkillLevelBadge skillLevel={player.skillLevel as any} showLabel />
              </div>
              <p className="text-sm mt-1">
                Record: {player.record.wins}-{player.record.losses}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">Challenge Rules</h4>
            <ul className="text-sm text-muted-foreground space-y-1 list-disc pl-5">
              <li>You can only challenge players up to 3 positions above you</li>
              <li>Challenges must be accepted within 7 days</li>
              <li>Matches must be completed within 14 days of acceptance</li>
              <li>Match results must be reported by both players</li>
            </ul>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" asChild>
            <Link href="/ladder">Cancel</Link>
          </Button>
          <Button>Send Challenge</Button>
        </CardFooter>
      </Card>
    </div>
  )
}

