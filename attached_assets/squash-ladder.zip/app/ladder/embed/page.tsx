import LadderWidget from "@/components/ladder-widget"

export default function EmbedPage() {
  return (
    <div className="p-4">
      <LadderWidget showHeader={true} limit={5} showChallengeButtons={false} showSkillLevel={true} />

      {/* Script to communicate with parent window for resizing */}
      <script
        dangerouslySetInnerHTML={{
          __html: `
        (function() {
          function sendHeight() {
            if (window.parent) {
              window.parent.postMessage({
                type: 'resize-ladder',
                height: document.body.scrollHeight
              }, '*');
            }
          }
          
          // Send height on load
          window.addEventListener('load', sendHeight);
          
          // Send height on resize
          window.addEventListener('resize', sendHeight);
          
          // Send height periodically to handle dynamic content changes
          setInterval(sendHeight, 1000);
        })();
      `,
        }}
      />
    </div>
  )
}

