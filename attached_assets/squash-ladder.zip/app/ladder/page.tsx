import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Trophy, ChevronUp, ChevronDown, Minus, ArrowLeft } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import SkillLevelBadge, { type SkillLevel } from "@/components/skill-level-badge"
import SkillFilterWrapper from "@/components/skill-filter-wrapper"

// Define player interface
interface Player {
  id: string
  name: string
  avatar: string
  gender: "male" | "female"
  skillLevel: SkillLevel
  record: {
    wins: number
    losses: number
  }
  movement: "up" | "down" | "none"
  lastMatch: string
}

// Sample data - static data for Replit/GitHub compatibility
const malePlayers: Player[] = [
  {
    id: "1",
    name: "Michael Chen",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "premier",
    record: { wins: 24, losses: 3 },
    movement: "none",
    lastMatch: "2 days ago",
  },
  {
    id: "2",
    name: "David Kim",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "division1",
    record: { wins: 22, losses: 5 },
    movement: "up",
    lastMatch: "Yesterday",
  },
  {
    id: "3",
    name: "James Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "division2",
    record: { wins: 19, losses: 7 },
    movement: "down",
    lastMatch: "3 days ago",
  },
  {
    id: "4",
    name: "Robert Taylor",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "division3",
    record: { wins: 18, losses: 8 },
    movement: "up",
    lastMatch: "1 week ago",
  },
  {
    id: "5",
    name: "John Smith",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "male",
    skillLevel: "division4",
    record: { wins: 16, losses: 9 },
    movement: "none",
    lastMatch: "5 days ago",
  },
]

// Female players data with skill levels
const femalePlayers: Player[] = [
  {
    id: "6",
    name: "Emma Rodriguez",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "premier",
    record: { wins: 21, losses: 4 },
    movement: "up",
    lastMatch: "Yesterday",
  },
  {
    id: "7",
    name: "Sarah Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "division1",
    record: { wins: 19, losses: 6 },
    movement: "none",
    lastMatch: "3 days ago",
  },
  {
    id: "8",
    name: "Maria Garcia",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "division2",
    record: { wins: 17, losses: 7 },
    movement: "up",
    lastMatch: "4 days ago",
  },
  {
    id: "9",
    name: "Jennifer Lee",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "division4",
    record: { wins: 15, losses: 8 },
    movement: "down",
    lastMatch: "1 week ago",
  },
  {
    id: "10",
    name: "Lisa Wong",
    avatar: "/placeholder.svg?height=40&width=40",
    gender: "female",
    skillLevel: "division5",
    record: { wins: 14, losses: 9 },
    movement: "none",
    lastMatch: "2 weeks ago",
  },
]

interface LadderPlayerCardProps {
  player: Player
  rank: number
  isTopThree: boolean
}

function LadderPlayerCard({ player, rank, isTopThree }: LadderPlayerCardProps) {
  return (
    <div className="flex items-center justify-between rounded-lg border p-4 transition-colors hover:bg-accent/50">
      <div className="flex items-center gap-4">
        <div className="relative flex h-10 w-10 items-center justify-center rounded-full bg-muted font-bold">
          {rank}
          {isTopThree && (
            <div className="absolute -top-1 -right-1">
              <Trophy className="h-4 w-4 text-yellow-500" />
            </div>
          )}
        </div>
        <Avatar className="h-10 w-10">
          <AvatarImage src={player.avatar} alt={player.name} />
          <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-medium">{player.name}</span>
            <SkillLevelBadge skillLevel={player.skillLevel} showLabel={true} />
          </div>
          <div className="text-sm text-muted-foreground">
            {player.record.wins}-{player.record.losses}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center">
          {player.movement === "up" && <ChevronUp className="h-4 w-4 text-green-500" />}
          {player.movement === "down" && <ChevronDown className="h-4 w-4 text-red-500" />}
          {player.movement === "none" && <Minus className="h-4 w-4 text-muted-foreground" />}
          <span className="text-sm text-muted-foreground ml-1">{player.lastMatch}</span>
        </div>
        <Button size="sm" asChild>
          <Link href={`/ladder/challenge/${player.id}`}>Challenge</Link>
        </Button>
      </div>
    </div>
  )
}

export default function LadderPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Main Site</span>
            </Link>
          </div>
          <div className="flex items-center gap-2">
            <Trophy className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">SquashLadder</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/ladder/register" className="text-sm font-medium text-muted-foreground hover:text-primary">
              Register
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="container py-8">
          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center gap-2">
                  <h2 className="text-2xl font-bold">Total Players</h2>
                  <div className="text-5xl font-bold text-primary">36</div>
                  <p className="text-sm text-muted-foreground">Active in the ladder</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center gap-2">
                  <h2 className="text-2xl font-bold">Recent Matches</h2>
                  <div className="text-3xl font-bold">
                    <span className="text-primary">12</span>
                  </div>
                  <p className="text-sm text-muted-foreground">In the last 7 days</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center gap-2">
                  <h2 className="text-2xl font-bold">Next Event</h2>
                  <div className="text-xl font-medium">Club Championship</div>
                  <p className="text-sm text-muted-foreground">June 10-12, 2025</p>
                  <Button size="sm" className="mt-2" asChild>
                    <Link href="/ladder/events/club-championship">View Details</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
        <section className="container py-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold">Ladder Rankings</h2>
            <div className="flex items-center gap-2">
              <SkillFilterWrapper />
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Search players..."
                  className="h-9 rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                />
              </div>
            </div>
          </div>

          <Tabs defaultValue="female" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8 max-w-md mx-auto">
              <TabsTrigger value="female">Women's Ladder</TabsTrigger>
              <TabsTrigger value="male">Men's Ladder</TabsTrigger>
            </TabsList>

            <TabsContent value="female" className="space-y-4">
              {femalePlayers.map((player, index) => (
                <LadderPlayerCard key={player.id} player={player} rank={index + 1} isTopThree={index < 3} />
              ))}
            </TabsContent>

            <TabsContent value="male" className="space-y-4">
              {malePlayers.map((player, index) => (
                <LadderPlayerCard key={player.id} player={player} rank={index + 1} isTopThree={index < 3} />
              ))}
            </TabsContent>
          </Tabs>
        </section>
      </main>
      <footer className="border-t py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} SquashLadder. All rights reserved.
          </p>
          <nav className="flex gap-4">
            <Link href="/ladder/terms" className="text-sm text-muted-foreground hover:text-primary">
              Terms
            </Link>
            <Link href="/ladder/privacy" className="text-sm text-muted-foreground hover:text-primary">
              Privacy
            </Link>
            <Link href="/ladder/contact" className="text-sm text-muted-foreground hover:text-primary">
              Contact
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

