"use client"

import { useState } from "react"
import LadderWidget from "./ladder-widget"
import { Button } from "@/components/ui/button"
import { Trophy } from "lucide-react"
import Link from "next/link"

interface LadderEmbedProps {
  baseUrl?: string
}

export default function LadderEmbed({ baseUrl = "/ladder" }: LadderEmbedProps) {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="w-full border rounded-lg shadow-sm overflow-hidden">
      <div className="bg-background p-4 border-b flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-bold">Squash Ladder</h2>
        </div>
        <div className="flex items-center gap-2">
          {expanded ? (
            <Button size="sm" variant="outline" onClick={() => setExpanded(false)}>
              Collapse
            </Button>
          ) : (
            <Button size="sm" variant="outline" onClick={() => setExpanded(true)}>
              Expand
            </Button>
          )}
          <Button size="sm" asChild>
            <Link href={baseUrl}>View Full Ladder</Link>
          </Button>
        </div>
      </div>

      <div className={expanded ? "p-4" : ""}>
        {expanded ? (
          <div className="grid gap-4 md:grid-cols-2">
            <LadderWidget
              title="Women's Ladder"
              showHeader={true}
              limit={5}
              showChallengeButtons={true}
              showSkillLevel={true}
              defaultTab="female"
            />
            <LadderWidget
              title="Men's Ladder"
              showHeader={true}
              limit={5}
              showChallengeButtons={true}
              showSkillLevel={true}
              defaultTab="male"
            />
          </div>
        ) : (
          <LadderWidget showHeader={false} limit={3} showChallengeButtons={false} showSkillLevel={true} />
        )}
      </div>
    </div>
  )
}

