"use client"

import { Button } from "@/components/ui/button"
import { ChevronLeft, Home } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"

interface BackButtonProps {
  fallbackUrl?: string
  showHomeOnRoot?: boolean
}

export default function BackButton({ fallbackUrl = "/", showHomeOnRoot = true }: BackButtonProps) {
  const pathname = usePathname()
  const isRootPath = pathname === "/"

  // If we're on the root path and showHomeOnRoot is false, don't show anything
  if (isRootPath && !showHomeOnRoot) {
    return null
  }

  return (
    <div className="mb-4">
      <Button variant="ghost" size="sm" asChild className="gap-1 px-2 hover:bg-accent">
        <Link href={isRootPath ? fallbackUrl : ".."}>
          {isRootPath ? (
            <>
              <Home className="h-4 w-4" />
              <span>Home</span>
            </>
          ) : (
            <>
              <ChevronLeft className="h-4 w-4" />
              <span>Back</span>
            </>
          )}
        </Link>
      </Button>
    </div>
  )
}

