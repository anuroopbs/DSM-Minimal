"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Trophy, ChevronUp, ChevronDown, Minus, ExternalLink } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface Player {
  id: string
  name: string
  avatar: string
  gender: "male" | "female"
  record: {
    wins: number
    losses: number
  }
  movement: "up" | "down" | "none"
  lastMatch: string
}

interface EmbedWidgetProps {
  apiUrl: string
  widgetType: "ladder" | "upcoming-matches" | "leaderboard"
  limit?: number
  showHeader?: boolean
  theme?: "light" | "dark"
}

export default function EmbedWidget({
  apiUrl,
  widgetType = "ladder",
  limit = 5,
  showHeader = true,
  theme = "light",
}: EmbedWidgetProps) {
  const [players, setPlayers] = useState<Player[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedGender, setSelectedGender] = useState<"male" | "female">("male")

  // Apply theme class
  useEffect(() => {
    const widgetElement = document.getElementById("squash-ladder-widget")
    if (widgetElement) {
      if (theme === "dark") {
        widgetElement.classList.add("dark")
      } else {
        widgetElement.classList.remove("dark")
      }
    }
  }, [theme])

  // Fetch data from API
  useEffect(() => {
    // In a real implementation, this would fetch from the provided apiUrl
    // For demo purposes, we'll use the sample data
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      try {
        // Sample data - in real implementation, fetch from apiUrl
        const samplePlayers = [
          {
            id: "1",
            name: "Michael Chen",
            avatar: "/placeholder.svg?height=40&width=40",
            gender: "male",
            record: { wins: 24, losses: 3 },
            movement: "none",
            lastMatch: "2 days ago",
          },
          {
            id: "2",
            name: "David Kim",
            avatar: "/placeholder.svg?height=40&width=40",
            gender: "male",
            record: { wins: 22, losses: 5 },
            movement: "up",
            lastMatch: "Yesterday",
          },
          {
            id: "3",
            name: "James Wilson",
            avatar: "/placeholder.svg?height=40&width=40",
            gender: "male",
            record: { wins: 19, losses: 7 },
            movement: "down",
            lastMatch: "3 days ago",
          },
          {
            id: "6",
            name: "Emma Rodriguez",
            avatar: "/placeholder.svg?height=40&width=40",
            gender: "female",
            record: { wins: 21, losses: 4 },
            movement: "up",
            lastMatch: "Yesterday",
          },
          {
            id: "7",
            name: "Sarah Johnson",
            avatar: "/placeholder.svg?height=40&width=40",
            gender: "female",
            record: { wins: 19, losses: 6 },
            movement: "none",
            lastMatch: "3 days ago",
          },
        ]

        setPlayers(samplePlayers)
        setLoading(false)
      } catch (err) {
        setError("Failed to load data")
        setLoading(false)
      }
    }, 1000)
  }, [apiUrl])

  // Filter players based on gender
  const filteredPlayers = players.filter((player) => player.gender === selectedGender).slice(0, limit)

  if (loading) {
    return (
      <div id="squash-ladder-widget" className="bg-background text-foreground p-4 rounded-lg border shadow-sm">
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div id="squash-ladder-widget" className="bg-background text-foreground p-4 rounded-lg border shadow-sm">
        <div className="text-center text-red-500 p-4">{error}</div>
      </div>
    )
  }

  return (
    <div id="squash-ladder-widget" className="bg-background text-foreground rounded-lg border shadow-sm">
      {showHeader && (
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-primary" />
            <span className="font-bold">SquashLadder</span>
          </div>
          <Button variant="outline" size="sm" asChild>
            <a href="https://yourmainwebsite.com/ladder" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-4 w-4 mr-1" />
              View Full Ladder
            </a>
          </Button>
        </div>
      )}

      <div className="p-4">
        <Tabs defaultValue="male" onValueChange={(value) => setSelectedGender(value as "male" | "female")}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="male">Men's Ladder</TabsTrigger>
            <TabsTrigger value="female">Women's Ladder</TabsTrigger>
          </TabsList>

          <TabsContent value="male" className="space-y-3">
            {filteredPlayers.map((player, index) => (
              <div
                key={player.id}
                className="flex items-center justify-between rounded-lg border p-3 transition-colors hover:bg-accent/50"
              >
                <div className="flex items-center gap-3">
                  <div className="relative flex h-8 w-8 items-center justify-center rounded-full bg-muted font-bold text-sm">
                    {index + 1}
                    {index < 3 && (
                      <div className="absolute -top-1 -right-1">
                        <Trophy className="h-3 w-3 text-yellow-500" />
                      </div>
                    )}
                  </div>
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={player.avatar} alt={player.name} />
                    <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-sm">{player.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {player.record.wins}-{player.record.losses}
                    </div>
                  </div>
                </div>
                <div className="flex items-center">
                  {player.movement === "up" && <ChevronUp className="h-4 w-4 text-green-500" />}
                  {player.movement === "down" && <ChevronDown className="h-4 w-4 text-red-500" />}
                  {player.movement === "none" && <Minus className="h-4 w-4 text-muted-foreground" />}
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="female" className="space-y-3">
            {filteredPlayers.map((player, index) => (
              <div
                key={player.id}
                className="flex items-center justify-between rounded-lg border p-3 transition-colors hover:bg-accent/50"
              >
                <div className="flex items-center gap-3">
                  <div className="relative flex h-8 w-8 items-center justify-center rounded-full bg-muted font-bold text-sm">
                    {index + 1}
                    {index < 3 && (
                      <div className="absolute -top-1 -right-1">
                        <Trophy className="h-3 w-3 text-yellow-500" />
                      </div>
                    )}
                  </div>
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={player.avatar} alt={player.name} />
                    <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-sm">{player.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {player.record.wins}-{player.record.losses}
                    </div>
                  </div>
                </div>
                <div className="flex items-center">
                  {player.movement === "up" && <ChevronUp className="h-4 w-4 text-green-500" />}
                  {player.movement === "down" && <ChevronDown className="h-4 w-4 text-red-500" />}
                  {player.movement === "none" && <Minus className="h-4 w-4 text-muted-foreground" />}
                </div>
              </div>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

