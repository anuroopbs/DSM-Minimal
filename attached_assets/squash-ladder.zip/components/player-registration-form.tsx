"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

// Define skill level type
type SkillLevel =
  | "premier" // Professional-level players
  | "division1" // Advanced 2
  | "division2" // Advanced 1
  | "division3" // Intermediate 2
  | "division4" // Intermediate 1
  | "division5" // Beginner 2
  | "division6" // Beginner 1

interface PlayerRegistrationFormProps {
  onSubmit: (data: PlayerFormData) => void
  isLoading?: boolean
}

export interface PlayerFormData {
  firstName: string
  lastName: string
  email: string
  gender: "male" | "female" | "other"
  skillLevel: SkillLevel
  club: string
  availability: string
  bio: string
  phone?: string
}

export default function PlayerRegistrationForm({ onSubmit, isLoading = false }: PlayerRegistrationFormProps) {
  const [formData, setFormData] = useState<PlayerFormData>({
    firstName: "",
    lastName: "",
    email: "",
    gender: "male",
    skillLevel: "division3", // Default to Intermediate 2
    club: "",
    availability: "",
    bio: "",
    phone: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Player Registration</CardTitle>
        <CardDescription>Join the squash ladder by providing your information below</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input id="firstName" name="firstName" value={formData.firstName} onChange={handleChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input id="lastName" name="lastName" value={formData.lastName} onChange={handleChange} required />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
          </div>

          <div className="space-y-2">
            <Label>Gender</Label>
            <RadioGroup
              value={formData.gender}
              onValueChange={(value) => handleSelectChange("gender", value)}
              className="flex flex-col space-y-1"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="male" id="male" />
                <Label htmlFor="male">Male</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="female" id="female" />
                <Label htmlFor="female">Female</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="other" id="other" />
                <Label htmlFor="other">Other</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="skillLevel">Division / Skill Level</Label>
            <Select value={formData.skillLevel} onValueChange={(value) => handleSelectChange("skillLevel", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select your division" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="premier">Premier – Professional-level players</SelectItem>
                <SelectItem value="division1">Division 1 – Top national players</SelectItem>
                <SelectItem value="division2">Division 2 – High-level club players</SelectItem>
                <SelectItem value="division3">Division 3 – Competitive intermediates</SelectItem>
                <SelectItem value="division4">Division 4 – Developing match tactics</SelectItem>
                <SelectItem value="division5">Division 5 – Newer players (4–12 months)</SelectItem>
                <SelectItem value="division6">Division 6 – Brand new to squash (0–3 months)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              This helps us place you appropriately in the ladder ranking
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="club">Home Club (Optional)</Label>
            <Input
              id="club"
              name="club"
              placeholder="Where do you usually play?"
              value={formData.club}
              onChange={handleChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number (Optional)</Label>
            <Input
              id="phone"
              name="phone"
              type="tel"
              placeholder="+1 (555) 123-4567"
              value={formData.phone}
              onChange={handleChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="availability">Availability</Label>
            <Input
              id="availability"
              name="availability"
              placeholder="e.g., Weekday evenings, Weekend mornings"
              value={formData.availability}
              onChange={handleChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">About You (Optional)</Label>
            <Textarea
              id="bio"
              name="bio"
              placeholder="Tell others about your squash experience"
              value={formData.bio}
              onChange={handleChange}
              className="resize-none"
              rows={3}
            />
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Submitting..." : "Register for Ladder"}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex justify-center text-sm text-muted-foreground">
        By registering, you agree to the ladder rules and code of conduct
      </CardFooter>
    </Card>
  )
}

