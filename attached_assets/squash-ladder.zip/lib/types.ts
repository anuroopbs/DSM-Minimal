export interface User {
  id: string
  name: string
  email: string
  avatar: string
  gender: "male" | "female" | "other"
  skillLevel: SkillLevel
  rank: number
  record: {
    wins: number
    losses: number
  }
  club: string
  availability: string
  joinedAt: Date
  bio?: string
  phone?: string
}

export type SkillLevel =
  | "premier" // Professional-level players
  | "division1" // Advanced 2
  | "division2" // Advanced 1
  | "division3" // Intermediate 2
  | "division4" // Intermediate 1
  | "division5" // Beginner 2
  | "division6" // Beginner 1

export interface Match {
  id: string
  challengerId: string
  opponentId: string
  challenger: User
  opponent: User
  scheduledDate: Date
  location?: string
  status: "pending" | "scheduled" | "completed" | "cancelled"
  result?: MatchResult
  createdAt: Date
  updatedAt: Date
}

export interface MatchResult {
  winnerId: string
  scores: {
    challengerScore: number
    opponentScore: number
  }[]
  comments?: string
  submittedBy: string
  confirmedBy?: string
  submittedAt: Date
  confirmedAt?: Date
}

export interface Challenge {
  id: string
  challengerId: string
  opponentId: string
  challenger: User
  opponent: User
  proposedDates: Date[]
  status: "pending" | "accepted" | "rejected" | "expired"
  matchId?: string
  createdAt: Date
  updatedAt: Date
}

export interface LadderRank {
  userId: string
  user: User
  ladderId: string
  rank: number
  previousRank: number
  movement: "up" | "down" | "none"
  lastMatchDate?: Date
  updatedAt: Date
}

export interface Ladder {
  id: string
  name: string
  gender: "male" | "female"
  description?: string
  rules?: {
    challengeRange: number
    matchFormat: "best-of-3" | "best-of-5"
    pointsSystem?: boolean
  }
  createdAt: Date
  updatedAt: Date
}

export interface Event {
  id: string
  title: string
  description: string
  startDate: Date
  endDate: Date
  location: string
  capacity: number
  participants: string[] // User IDs
  fee?: number
  createdBy: string
  createdAt: Date
  updatedAt: Date
}

export interface ForumTopic {
  id: string
  title: string
  content: string
  authorId: string
  author: User
  replies: ForumReply[]
  createdAt: Date
  updatedAt: Date
}

export interface ForumReply {
  id: string
  topicId: string
  content: string
  authorId: string
  author: User
  createdAt: Date
  updatedAt: Date
}

